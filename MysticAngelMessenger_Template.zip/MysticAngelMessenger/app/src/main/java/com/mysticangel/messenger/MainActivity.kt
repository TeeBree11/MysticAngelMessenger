package com.mysticangel.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mysticangel.messenger.ui.theme.MysticAngelMessengerTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MysticAngelMessengerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DailyMessageScreen()
                }
            }
        }
    }
}

@Composable
fun DailyMessageScreen() {
    val messages = listOf(
        "You are surrounded by divine light.",
        "Trust the timing of the universe.",
        "Your intuition is your greatest gift.",
        "Embrace the unknown with open arms."
    )
    var message by remember { mutableStateOf(messages.random()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = message, style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = { message = messages.random() }) {
            Text("Receive Another Message")
        }
    }
}
